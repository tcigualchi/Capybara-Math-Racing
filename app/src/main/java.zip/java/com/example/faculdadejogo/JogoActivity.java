package com.example.faculdadejogo;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.bumptech.glide.Glide;
import java.util.Random;

public class JogoActivity extends AppCompatActivity {

    private TextView tvEquacao, tvResultado, tvDificuldadeSelecionada, tvScore, tvExplicacao;
    private EditText etResposta;
    private ImageButton btnMute, btnDica;
    private ImageView backgroundGif;
    private RelativeLayout layoutJogo;
    private String dificuldadeSelecionada;
    private int respostaCorreta;
    private int num1, num2;
    private char operador;
    private int pontos = 30;
    private static final int PONTOS_ACERTO = 10;
    private static final int PONTOS_ERRO = 10;
    private static final int CUSTO_DICA = 30;
    private Random random = new Random();
    private MediaPlayer mediaPlayer;
    private boolean isMuted = false;
    private boolean isActivityAlive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jogo);
        isActivityAlive = true;
        inicializarViews();
        configurarJogo();
    }

    private void inicializarViews() {
        backgroundGif = findViewById(R.id.backgroundGif);
        layoutJogo = findViewById(R.id.layoutJogo);
        tvEquacao = findViewById(R.id.tvEquacao);
        tvResultado = findViewById(R.id.tvResultado);
        tvDificuldadeSelecionada = findViewById(R.id.tvDificuldadeSelecionada);
        tvScore = findViewById(R.id.tvScore);
        tvExplicacao = findViewById(R.id.tvExplicacao);
        etResposta = findViewById(R.id.etResposta);
        btnMute = findViewById(R.id.btnMute);
        btnDica = findViewById(R.id.btnDica);
        Button btnVoltarJogo = findViewById(R.id.btnVoltarJogo);
    }

    private void configurarJogo() {
        if (isActivityAlive) {
            Glide.with(this).load(R.drawable.backgif).into(backgroundGif);
        }

        Intent intent = getIntent();
        dificuldadeSelecionada = intent.getStringExtra("DIFICULDADE");
        tvDificuldadeSelecionada.setText("DIFÍCULDADE: " + dificuldadeSelecionada);
        atualizarPlacar();
        configurarMusica();
        gerarNovaEquacao();
        configurarListeners();
    }

    private void configurarMusica() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.original);
            if (mediaPlayer != null) {
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void configurarListeners() {
        etResposta.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE && isActivityAlive) {
                verificarResposta();
                return true;
            }
            return false;
        });

        findViewById(R.id.btnVoltarJogo).setOnClickListener(v -> {
            if (isActivityAlive) {
                finishSafely();
            }
        });

        btnMute.setOnClickListener(v -> {
            if (isActivityAlive) {
                toggleMute();
            }
        });

        btnDica.setOnClickListener(v -> {
            if (isActivityAlive && pontos >= CUSTO_DICA) {
                mostrarDica();
            }
        });

        layoutJogo.setOnClickListener(v -> {
            if (isActivityAlive) {
                tvResultado.setText("");
                showSoftKeyboard();
            }
        });
    }

    private void mostrarDica() {
        pontos -= CUSTO_DICA;
        atualizarPlacar();

        String dica = gerarDica();
        tvExplicacao.setText(dica);
        tvExplicacao.setVisibility(TextView.VISIBLE);

        new Handler().postDelayed(() -> {
            if (isActivityAlive) {
                tvExplicacao.setVisibility(TextView.GONE);
            }
        }, 5000);
    }

    private String gerarDica() {
        switch (operador) {
            case '+':
                return "Dica: Some " + num1 + " + " + num2 + ":\n\n" +
                        "Conte " + num2 + " números a partir de " + num1 + ":\n" +
                        num1 + " → " + (num1 + 1) + " → ... → " + (num1 + num2) + "\n\n" +
                        "Resultado: " + (num1 + num2);

            case '-':
                return "Dica: Subtraia " + num1 + " - " + num2 + ":\n\n" +
                        "Conte " + num2 + " números para trás a partir de " + num1 + ":\n" +
                        num1 + " → " + (num1 - 1) + " → ... → " + (num1 - num2) + "\n\n" +
                        "Resultado: " + (num1 - num2);

            case '*':
                return "Dica: Multiplique " + num1 + " × " + num2 + ":\n\n" +
                        "Some " + num1 + " por ele mesmo " + num2 + " vezes:\n" +
                        num1 + " + " + num1 + " = " + (num1*2) + "\n" +
                        (num1 > 2 ? "...\n" : "") +
                        num1 + " + ... + " + num1 + " = " + (num1*num2) + " (" + num2 + " vezes)\n\n" +
                        "Resultado: " + (num1 * num2);

            default:
                return "";
        }
    }

    private void finishSafely() {
        isActivityAlive = false;
        releaseMediaPlayer();
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityAlive = true;
        if (mediaPlayer != null && !isMuted) {
            mediaPlayer.start();
        }
        showSoftKeyboard();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isActivityAlive = false;
        releaseMediaPlayer();
    }

    private void releaseMediaPlayer() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
            mediaPlayer = null;
        }
    }

    private void showSoftKeyboard() {
        if (isActivityAlive) {
            etResposta.post(() -> {
                etResposta.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(etResposta, InputMethodManager.SHOW_IMPLICIT);
                }
            });
        }
    }

    private void hideSoftKeyboard() {
        if (isActivityAlive) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && getCurrentFocus() != null) {
                imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        }
    }

    private void gerarNovaEquacao() {
        if (!isActivityAlive) return;

        int limite = definirLimite(dificuldadeSelecionada);
        num1 = random.nextInt(limite) + 1;
        num2 = random.nextInt(limite) + 1;
        operador = new char[]{'+', '*', '-'}[random.nextInt(3)];

        if (operador == '-' && num1 < num2) {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        tvEquacao.setText(num1 + " " + operador + " " + num2 + " = ?");
        respostaCorreta = calcularResultado(num1, num2, operador);
        tvExplicacao.setVisibility(TextView.GONE);
    }

    private void verificarResposta() {
        if (!isActivityAlive) return;

        String respostaUsuario = etResposta.getText().toString();
        if (!respostaUsuario.isEmpty()) {
            try {
                int resposta = Integer.parseInt(respostaUsuario);
                hideSoftKeyboard();
                if (resposta == respostaCorreta) {
                    mostrarAcerto();
                } else {
                    mostrarErro();
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    private void mostrarAcerto() {
        if (!isActivityAlive) return;

        pontos += PONTOS_ACERTO;
        atualizarPlacar();
        tvResultado.setText("Correto! +" + PONTOS_ACERTO + " pontos");
        tvResultado.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        etResposta.setText("");
        gerarNovaEquacao();
    }

    private void mostrarErro() {
        if (!isActivityAlive) return;

        pontos = Math.max(0, pontos - PONTOS_ERRO);
        atualizarPlacar();

        String solucao = "Errado! -" + PONTOS_ERRO + " pontos\n\n";
        solucao += "Solução detalhada:\n\n";
        solucao += gerarExplicacaoDetalhada();

        tvResultado.setText(solucao);
        tvResultado.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));

        if (isActivityAlive) {
            Glide.with(this).load(R.drawable.backerror).into(backgroundGif);
        }

        Animation tremor = AnimationUtils.loadAnimation(this, R.anim.tremor);
        layoutJogo.startAnimation(tremor);
        vibrar();

        new Handler().postDelayed(() -> {
            if (isActivityAlive) {
                Glide.with(JogoActivity.this).load(R.drawable.backgif).into(backgroundGif);
                etResposta.setText("");
                gerarNovaEquacao();
            }
        }, 5000);
    }

    private String gerarExplicacaoDetalhada() {
        // Regras para mostrar apenas o Método 2:
        // 1. Multiplicação acima de 25×25
        // 2. Adição/Subtração onde qualquer número ≥ 50
        boolean mostrarApenasMetodo2 =
                (operador == '*' && (num1 > 25 || num2 > 25)) ||  // Multiplicação >25
                        (operador != '*' && (num1 >= 50 || num2 >= 50));  // Adição/Subtração ≥50

        switch (operador) {
            case '+':
                if (mostrarApenasMetodo2) {
                    return "Adição grande:\n" + num1 + " + " + num2 + " =\n\n" +
                            "Método: Decomposição\n" +
                            "Quebre em partes mais fáceis:\n" +
                            num1 + " + " + num2 + " = (" + (num1/2) + " + " + (num1 - num1/2) + ") + " + num2 + " =\n" +
                            (num1/2 + num2) + " + " + (num1 - num1/2) + " = " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                } else {
                    return "Adição:\n" + num1 + " + " + num2 + " =\n\n" +
                            "Método 1: Contagem progressiva\n" +
                            "Conte " + num2 + " a partir de " + num1 + ":\n" +
                            gerarSequenciaContagem(num1, num2, true) + "\n\n" +
                            "Método 2: Decomposição\n" +
                            num1 + " + " + num2 + " = (" + (num1/2) + " + " + (num1 - num1/2) + ") + " + num2 + " =\n" +
                            (num1/2 + num2) + " + " + (num1 - num1/2) + " = " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                }

            case '-':
                if (mostrarApenasMetodo2) {
                    return "Subtração grande:\n" + num1 + " - " + num2 + " =\n\n" +
                            "Método: Adição inversa\n" +
                            "Pense: " + num2 + " + ? = " + num1 + "\n" +
                            "Resposta: " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                } else {
                    return "Subtração:\n" + num1 + " - " + num2 + " =\n\n" +
                            "Método 1: Contagem regressiva\n" +
                            "Conte " + num2 + " para trás a partir de " + num1 + ":\n" +
                            gerarSequenciaContagem(num1, num2, false) + "\n\n" +
                            "Método 2: Adição inversa\n" +
                            num2 + " + ? = " + num1 + "\n" +
                            "Resposta: " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                }

            case '*':
                if (mostrarApenasMetodo2) {
                    return "Multiplicação:\n" + num1 + " × " + num2 + " =\n\n" +
                            "Método: Decomposição\n" +
                            "Quebre em partes menores:\n" +
                            num1 + " × " + num2 + " = (" + (num1/2) + " × " + num2 + ") + (" + (num1 - num1/2) + " × " + num2 + ") =\n" +
                            (num1/2 * num2) + " + " + ((num1 - num1/2) * num2) + " = " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                } else {
                    return "Multiplicação:\n" + num1 + " × " + num2 + " =\n\n" +
                            "Método 1: Adição repetida\n" +
                            "Some " + num1 + " por ele mesmo " + num2 + " vezes:\n" +
                            gerarSequenciaMultiplicacao(num1, num2) + "\n\n" +
                            "Método 2: Decomposição\n" +
                            num1 + " × " + num2 + " = (" + (num1/2) + " × " + num2 + ") + (" + (num1 - num1/2) + " × " + num2 + ") =\n" +
                            (num1/2 * num2) + " + " + ((num1 - num1/2) * num2) + " = " + respostaCorreta + "\n\n" +
                            "Resposta: " + respostaCorreta;
                }

            default:
                return "";
        }
    }

    private String gerarSequenciaContagem(int inicio, int quantidade, boolean progressiva) {
        StringBuilder sb = new StringBuilder();
        sb.append(inicio);

        int passo = progressiva ? 1 : -1;
        int atual = inicio;

        for (int i = 1; i <= quantidade; i++) {
            atual += passo;
            sb.append(" → ").append(atual);
        }

        return sb.toString();
    }

    private String gerarSequenciaMultiplicacao(int num, int vezes) {
        StringBuilder sb = new StringBuilder();
        int total = 0;

        for (int i = 1; i <= vezes; i++) {
            total += num;
            if (i > 1) sb.append(" + ");
            sb.append(num);
            if (i == vezes) sb.append(" = ").append(total);
        }

        return sb.toString();
    }

    private void vibrar() {
        if (!isActivityAlive) return;

        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(1000);
            }
        }
    }

    private void toggleMute() {
        if (!isActivityAlive || mediaPlayer == null) return;

        if (isMuted) {
            mediaPlayer.setVolume(1.0f, 1.0f);
            btnMute.setImageResource(R.drawable.unmuted);
            isMuted = false;
        } else {
            mediaPlayer.setVolume(0.0f, 0.0f);
            btnMute.setImageResource(R.drawable.muted);
            isMuted = true;
        }
    }

    private void atualizarPlacar() {
        if (isActivityAlive) {
            tvScore.setText("PONTOS: " + pontos);
        }
    }

    private int definirLimite(String dificuldade) {
        switch (dificuldade) {
            case "FÁCIL": return 15;
            case "MÉDIO": return 50;
            case "DIFÍCIL": return 100;
            default: return 15;
        }
    }

    private int calcularResultado(int num1, int num2, char operador) {
        switch (operador) {
            case '+': return num1 + num2;
            case '-': return num1 - num2;
            case '*': return num1 * num2;
            default: return 0;
        }
    }
}
