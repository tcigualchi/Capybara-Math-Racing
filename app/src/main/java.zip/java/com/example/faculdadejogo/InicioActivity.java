package com.example.faculdadejogo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView; // Importe ImageView
import androidx.appcompat.app.AppCompatActivity;
import android.media.AudioManager;
import android.media.MediaPlayer;

public class InicioActivity extends AppCompatActivity {

    private Button btnFacil, btnMedio;
    private ImageView btnDificil; // Mude para ImageView
    MediaPlayer mediaPlayer;

    private void playMusic() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(InicioActivity.this, R.raw.original); // Certifique-se de que original.mp3 está em res/raw/
        mediaPlayer.start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btnFacil = findViewById(R.id.btnFacil);
        btnMedio = findViewById(R.id.btnMedio);
        btnDificil = findViewById(R.id.btnDificil); // Agora é um ImageView

        btnFacil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarJogo("FÁCIL");
            }
        });

        btnMedio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarJogo("MÉDIO");
            }
        });

        btnDificil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iniciarJogo("DIFÍCIL");
            }
        });
    }

    private void iniciarJogo(String dificuldade) {
        Intent intent = new Intent(InicioActivity.this, JogoActivity.class);
        intent.putExtra("DIFICULDADE", dificuldade);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}